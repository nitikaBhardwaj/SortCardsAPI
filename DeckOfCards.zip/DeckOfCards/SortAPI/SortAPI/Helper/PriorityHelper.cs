﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SortCardsAPI
{
    public static class PriorityHelper
    {
        public static IDictionary<string, int> Cards = new Dictionary<string, int>()
            {{"4T",0 },{"2T",1 },{"ST",2},{"PT",3 },{"RT",4 },
            { "2D",5 },{"3D",6 },{"4D",7 },{"5D",8 },{"6D",9 },{"7D",10 },{"8D",11 },{"9D",12 },{"10D",12 },{"JD",13 },{"QD",14 },{"KD",15 },{"AD",16 },
            { "2S",17 },{"3S",18 },{"4S",19 },{"5S",20 },{"6S",21 },{"7S",22 },{"8S",23 },{"9S",24 },{"10S",25 },{"JS",26 },{"QS",27 },{"KS",28 },{"AS",29 },
            { "2C",30 },{"3C",31 },{"4C",32 },{"5C",33 },{"6C",34 },{"7C",35 },{"8C",36 },{"9C",37 },{"10C",38 },{"JC",39 },{"QC",40 },{"KC",41 },{"AC",42 },
            { "2H", 43 },{"3H",44 },{"4H",45 },{"5H",46 },{"6H",47 },{"7H",48 },{"8H",49 },{"9H",50 },{"10H",51 },{"JH",52 },{"QH",53 },{"KH",54 },{"AH",55 }
        };
    }
}
