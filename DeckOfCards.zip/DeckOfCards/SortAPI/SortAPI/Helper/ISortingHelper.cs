﻿using System.Collections.Generic;

namespace SortCardsAPI.Helper
{
    public interface ISortingHelper
    {
        string SortCards(string cardstoSort);
    }
}