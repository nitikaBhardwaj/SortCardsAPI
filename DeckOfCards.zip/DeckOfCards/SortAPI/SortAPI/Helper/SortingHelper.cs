﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SortCardsAPI.Helper
{
    public class SortingHelper : ISortingHelper
    {
        public string SortCards(string cards)
        {
            IList<string> sortedCards = new List<string>();
            string[] cardstoSort = cards.Split(",");
            int[] cardKeys = new int[cardstoSort.Length];
            for (int i = 0; i < cardstoSort.Length; i++)
            {
                if (PriorityHelper.Cards.ContainsKey(cardstoSort[i]))
                {
                    cardKeys[i] = PriorityHelper.Cards[cardstoSort[i]];
                }
                else
                {
                    return cardstoSort[i] + " Card not valid! Please enter valid cards.";
                }
            }

            Array.Sort(cardKeys);

            for (int j = 0; j < cardKeys.Length; j++)
            {
                sortedCards.Add(PriorityHelper.Cards.First(a => a.Value == cardKeys[j]).Key);
            }

            return String.Join(",", sortedCards);
        }
    }
}
