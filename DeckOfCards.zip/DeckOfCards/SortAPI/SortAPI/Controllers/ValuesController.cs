﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SortCardsAPI.Helper;

namespace SortCardsAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        public ISortingHelper sortingHelper;

        public ValuesController(ISortingHelper sortingHelper)
        {
            this.sortingHelper = sortingHelper;
        }

        // GET api/values
        [Route("api/sortcards")]
        [HttpPost]
        public JsonResult SortListWithPriority([FromBody] string cardsToSort)
        {
            //return JsonConvert.DeserializeObject(sortingHelper.SortCards(cardsToSort));
            //var result = new JsonResult
            //{
            //    Data = JsonConvert.SerializeObject(sortingHelper.SortCards(cardsToSort))
            //};

            return new JsonResult(sortingHelper.SortCards(cardsToSort));

        }

    }
}
